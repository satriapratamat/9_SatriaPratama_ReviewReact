import { validateName } from "./ValidasiNama";
import { validateEmail } from "./ValidasiEmail";
import { validateNoTelp } from "./ValidasiNoTelp";

export { validateName, validateEmail, validateNoTelp  }