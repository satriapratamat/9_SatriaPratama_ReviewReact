export function validateEmail(emailAddress) {
  const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  const isValid = regex.test(emailAddress);
  if (emailAddress.trim() === "") {
    return {
      status: false,
      message: "Email can't be empty",
    };
  }
  if (isValid) {
    return { status: true };
  } else {
    return {
      status: false,
      message: "Please enter a valid email value",
    };
  }
}