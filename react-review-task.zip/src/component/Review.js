import React from "react";
import "./css/review.css";
import dotDot from "./img/img-dot@2x.png";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

function Review() {
  const formData = useSelector((state) => state.formData.formData);
  return (
      <>
      <div className="container">
        <div className="row">
            <div className="col-md-2"></div>
            <div className="col-md-8 kotak">
                <div className="row">
                    <div className="col-md-3">Full name</div>
                    <div className="col-md-9">: {formData.fullName}</div>
                </div>
                <div className="row">
                    <div className="col-md-3">Email</div>
                    <div className="col-md-9">: {formData.emailAddress}</div>
                </div>
                <div className="row">
                    <div className="col-md-3">Phone Number</div>
                    <div className="col-md-9">: {formData.phoneNumber}</div>
                </div>
                <div className="row">
                    <div className="col-md-3">Nationality</div>
                    <div className="col-md-9">: {formData.nationality}</div>
                </div>
                <div className="row message-show">
                    <div>{formData.message}</div>
                </div>
                <div className="ujung-kotak">
                    <div className="row">
                        <div className= 'col-md-2'></div>
                        <div className= 'col-md-8 pembatas'><p></p></div>
                        <div className= 'col-md-2'></div>
                    </div>
                    <div className='keep-in-touch'>
                        <div>Thanks for contacting us!</div>
                        <div>We will be touch with you shortly</div>
                    </div>
                    <Link to="/">
                        <button className="btn btn-orange">Home</button>
                    </Link>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
    <footer>
        <div class="row">
            <div class= 'col-md-2'></div>
            <div class= 'col-md-2 dot-blue'><img src={dotDot} alt=""/></div>
            <div class= 'col-md-2'></div>
            <div class= 'col-md-2'></div>
            <div class= 'col-md-2'></div>
            <div class= 'col-md-2'></div>
        </div>
    </footer>
    </>
  );
}

export default Review;